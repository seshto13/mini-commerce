interface Cart {
  id: number;
  img: string;
  mainTitle: string;
  content: string;
  price: number;
}
